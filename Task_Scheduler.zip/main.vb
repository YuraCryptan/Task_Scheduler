' Task Scheduler
Module Module1
Sub Main()
Console.WriteLine("Task Scheduler Initialized")
End Sub
End Module